export { default } from "./SvgColor";
