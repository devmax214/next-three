type Props = {};

export default function SplashScreen(props: Props) {
  return <>SplashScreen</>;
}
