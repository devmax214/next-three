import { PATH_CONFIGURATOR } from "@/routers/path";

export const navConfig = [
  // { title: "Customized Product Gallery", path: PATH_CONFIGURATOR.gallery },
  { title: "about us", path: PATH_CONFIGURATOR.about },
  { title: "faq", path: PATH_CONFIGURATOR.faqs },
  { title: "community", path: PATH_CONFIGURATOR.community },
  // { title: "newsletter ", path: PATH_CONFIGURATOR.newsletter },
];
