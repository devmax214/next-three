export { default } from "./discount-bar";
