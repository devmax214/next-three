export { default as CustomerListView } from "./customer-list-view";
export { default as CustomerEditView } from "./customer-edit-view";
