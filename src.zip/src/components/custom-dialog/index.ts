export { default as ConfirmDialog } from "./custom-dialog";
