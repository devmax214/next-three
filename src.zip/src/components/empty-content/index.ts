export { default } from "./EmptyContent";
