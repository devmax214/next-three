type Props = {};

export default function Option3Icon(props: Props) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="69"
      height="30"
      viewBox="0 0 69 30"
      fill="none"
    >
      <rect x="1" y="1" width="67" height="28" stroke="#5C6166" />
      <path d="M63.25 24.75V4.75" stroke="#5C6166" stroke-dasharray="2 2" />
      <path d="M7.25 24.75L7.25 4.75" stroke="#5C6166" stroke-dasharray="2 2" />
    </svg>
  );
}
