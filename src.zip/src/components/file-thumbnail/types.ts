export interface ExtendFile extends File {
  preview?: string;
  path?: string;
  lastModifiedDate?: string;
}
