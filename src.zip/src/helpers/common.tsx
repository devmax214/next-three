function ptypeToEmbelIndex(ptype: string) {
  const embelIndex = 0;

  return embelIndex;
}

function ptypeToEmbelLabel(ptype: string) {
  const embelLabel = "label";

  return embelLabel;
}

export { ptypeToEmbelIndex, ptypeToEmbelLabel };