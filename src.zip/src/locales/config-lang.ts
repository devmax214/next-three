export const allLangs = [
  { value: "en", label: "ENG" },
  { value: "pt", label: "PT" },
  { value: "es", label: "ES" },
];

export const defaultLang = allLangs[0];
