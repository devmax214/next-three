export * from "./config-lang";

export { default as useLocales } from "./useLocales";
export { default as LocalizationProvider } from "./LocalizationProvider";
