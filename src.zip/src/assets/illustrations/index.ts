export { default as UploadIllustration } from "./UploadIllustration";
